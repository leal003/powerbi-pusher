class PhazeError(Exception):
    pass

class LocalAutomationError(PhazeError):
    pass

class ConnectionError(PhazeError):
    pass